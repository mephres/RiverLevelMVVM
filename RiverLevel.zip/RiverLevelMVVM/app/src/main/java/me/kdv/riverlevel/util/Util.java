package me.kdv.riverlevel.util;

public class Util {
    public static final String API_ENDPOINT = "http://www.meteorb.ru/";
}
