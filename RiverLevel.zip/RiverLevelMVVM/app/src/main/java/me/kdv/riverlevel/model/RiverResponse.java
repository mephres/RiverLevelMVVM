package me.kdv.riverlevel.model;

import java.util.List;

public class RiverResponse {
    List<River> riverList;

    public List<River> getRiverList() {
        return riverList;
    }

    public void setRiverList(List<River> riverList) {
        this.riverList = riverList;
    }
}
