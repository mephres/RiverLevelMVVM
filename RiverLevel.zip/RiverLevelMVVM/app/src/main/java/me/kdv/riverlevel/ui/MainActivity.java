package me.kdv.riverlevel.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;


import android.os.Bundle;
import android.view.View;

import me.kdv.riverlevel.databinding.ActivityMainBinding;
import me.kdv.riverlevel.model.RiverResponse;
import me.kdv.riverlevel.viewmodel.MainActivityViewModel;

import static androidx.lifecycle.ViewModelProviders.of;


public class MainActivity extends AppCompatActivity {

    private MainActivityViewModel viewModel;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());

        viewModel = of(this).get(MainActivityViewModel.class);
        viewModel.init();
        viewModel.getRiverLevel().observe(this, new Observer<RiverResponse>() {
            @Override
            public void onChanged(RiverResponse riverResponse) {
                return;
            }
        });
    }
}
